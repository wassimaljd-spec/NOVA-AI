import express from "express";
import OpenAI from "openai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json());

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

app.post("/api/chat", async (req, res) => {
  try {
    const message = req.body.message;

    if (!message) {
      return res.status(400).json({ error: "No message provided." });
    }

    const response = await client.responses.create({
      model: "gpt-5.6-luna",
      input: [
        {
          role: "system",
          content: "You are Nova, a friendly helpful AI assistant. Keep responses natural and conversational."
        },
        { role: "user", content: message }
      ]
    });

    res.json({ reply: response.output_text });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Nova couldn't respond." });
  }
});

app.listen(3000, () => {
  console.log("Nova backend running on http://localhost:3000");
});
